namespace Logic {
 public static class ActivityLog {
 public static List<string> Logs = new List<string>();
 public static void Add(string log) {
 Logs.Add(log);
 }
 }
}