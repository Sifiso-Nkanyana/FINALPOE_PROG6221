namespace Logic {
 public class NLPProcessor {
 public string Interpret(string input) {
 return "Simulated response";
 }
 }
}