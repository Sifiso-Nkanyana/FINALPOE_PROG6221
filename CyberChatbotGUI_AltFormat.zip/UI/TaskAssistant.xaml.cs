public partial class TaskAssistant : UserControl {
 public TaskAssistant() {
 InitializeComponent();
 }
}