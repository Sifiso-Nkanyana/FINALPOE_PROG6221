public partial class QuizGame : UserControl {
 public QuizGame() {
 InitializeComponent();
 }
}